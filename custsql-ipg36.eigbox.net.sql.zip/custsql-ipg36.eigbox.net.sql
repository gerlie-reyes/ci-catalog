-- phpMyAdmin SQL Dump
-- version 2.8.0.1
-- http://www.phpmyadmin.net
-- 
-- Host: custsql-ipg36.eigbox.net
-- Generation Time: Jan 24, 2015 at 09:27 PM
-- Server version: 5.5.32
-- PHP Version: 4.4.9
-- 
-- Database: `sneakertradeph`
-- 
CREATE DATABASE `sneakertradeph` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `sneakertradeph`;

-- --------------------------------------------------------

-- 
-- Table structure for table `ci_sessions`
-- 

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `ci_sessions`
-- 

INSERT INTO `ci_sessions` VALUES ('cb333963c425a42fe72cff838fa1b274', '112.198.83.110', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36', 1422152012, '');
INSERT INTO `ci_sessions` VALUES ('f55867ba4fd6cb7858da1fad79d17574', '112.198.83.243', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36', 1421935624, '');

-- --------------------------------------------------------

-- 
-- Table structure for table `products`
-- 

CREATE TABLE `products` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `condition` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `size` int(11) NOT NULL,
  `author` varchar(255) NOT NULL,
  `date_posted` datetime NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `products`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(255) NOT NULL,
  `fbid` varchar(255) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `birthday` date NOT NULL,
  `location` varchar(255) NOT NULL,
  `fb_token` text NOT NULL,
  `date_reg` datetime NOT NULL,
  `last_login` datetime NOT NULL,
  `active` int(11) NOT NULL,
  `registration_hash` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `users`
-- 

INSERT INTO `users` VALUES (1, 'mPD8JbD2X8nhpFXPlJ40_1421169473', '10203000518922543', 'mendozagerlie', '891c5feef171da85aadd3fdb8130ba509b03f5ea', 'Gerlie', 'Reyes', '09066600084', 'mendozagerlie@gmail.com', 'female', '0000-00-00', 'Mandaluyong City', '', '2015-01-14 01:17:32', '0000-00-00 00:00:00', 1, NULL);
